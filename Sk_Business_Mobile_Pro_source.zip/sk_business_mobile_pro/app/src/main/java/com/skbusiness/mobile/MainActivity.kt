package com.skbusiness.mobile

import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private const val RED = 0xFFB71C1C.toInt()
private const val DARK = 0xFF242424.toInt()
private const val PALE = 0xFFF7F7F7.toInt()

class StoreDb(context: android.content.Context) : SQLiteOpenHelper(context, "sk_business.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, start_qty REAL NOT NULL, added_qty REAL NOT NULL DEFAULT 0, remaining_qty REAL NOT NULL, price REAL NOT NULL)")
        db.execSQL("CREATE TABLE sales(id INTEGER PRIMARY KEY AUTOINCREMENT, product_id INTEGER, product_name TEXT, qty REAL, amount REAL, currency TEXT, created_at INTEGER)")
        db.execSQL("CREATE TABLE cash_moves(id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT, amount REAL, note TEXT, currency TEXT, created_at INTEGER)")
        db.execSQL("CREATE TABLE settings(key TEXT PRIMARY KEY, value TEXT)")
        db.execSQL("INSERT INTO settings(key,value) VALUES('opening_fund','0'),('currency','USD')")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
}

class MainActivity : Activity() {
    private lateinit var db: StoreDb
    private lateinit var root: LinearLayout
    private lateinit var body: LinearLayout
    private var currency = "USD"
    private val moneyFmt = java.text.DecimalFormat("#,##0.00")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = StoreDb(this)
        currency = setting("currency", "USD")
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(PALE) }
        val header = TextView(this).apply {
            text = "SK BUSINESS MOBILE PRO\nGestion commerciale"
            setTextColor(Color.WHITE); textSize = 20f; gravity = Gravity.CENTER_VERTICAL
            setPadding(20, 18, 20, 18); setBackgroundColor(RED)
        }
        root.addView(header)
        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setBackgroundColor(Color.WHITE) }
        listOf("Accueil", "Produits", "Vente", "Caisse").forEach { label ->
            nav.addView(Button(this).apply { text = label; textSize = 11f; setOnClickListener { when(label) {
                "Accueil" -> showDashboard(); "Produits" -> showProducts(); "Vente" -> showSale(); else -> showCash()
            } } }, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(nav)
        val scroll = ScrollView(this)
        body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 14, 16, 24) }
        scroll.addView(body)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        showDashboard()
    }

    private fun setting(key: String, fallback: String): String {
        val c = dbOrNull()?.readableDatabase?.rawQuery("SELECT value FROM settings WHERE key=?", arrayOf(key))
        val value = if (c != null && c.moveToFirst()) c.getString(0) else fallback
        c?.close(); return value
    }
    private fun dbOrNull(): StoreDb? = if (::db.isInitialized) db else null
    private fun saveSetting(key: String, value: String) {
        val cv = ContentValues().apply { put("key", key); put("value", value) }
        db.writableDatabase.insertWithOnConflict("settings", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
    }
    private fun reset(title: String) {
        body.removeAllViews()
        body.addView(TextView(this).apply { text = title; textSize = 22f; setTextColor(RED); setPadding(0, 0, 0, 12); setTypeface(null, android.graphics.Typeface.BOLD) })
    }
    private fun label(text: String) { body.addView(TextView(this).apply { this.text = text; textSize = 15f; setTextColor(DARK); setPadding(0, 7, 0, 7) }) }
    private fun edit(hint: String, numeric: Boolean = false): EditText = EditText(this).apply {
        this.hint = hint; textSize = 16f
        if (numeric) inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
        body.addView(this, LinearLayout.LayoutParams(-1, -2))
    }
    private fun action(text: String, callback: () -> Unit) {
        body.addView(Button(this).apply { this.text = text; setTextColor(Color.WHITE); setBackgroundColor(RED); setOnClickListener { callback() } }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 8; bottomMargin = 4 })
    }
    private fun parse(e: EditText): Double = e.text.toString().trim().replace(',', '.').toDoubleOrNull() ?: 0.0
    private fun fmt(v: Double): String = moneyFmt.format(v)
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun scalar(sql: String, args: Array<String> = emptyArray()): Double {
        val c = db.readableDatabase.rawQuery(sql, args); val result = if (c.moveToFirst()) c.getDouble(0) else 0.0; c.close(); return result
    }
    private fun showDashboard() {
        reset("Tableau de bord")
        val sales = scalar("SELECT COALESCE(SUM(amount),0) FROM sales")
        val expenses = scalar("SELECT COALESCE(SUM(amount),0) FROM cash_moves WHERE kind IN ('Dépense','Retrait')")
        val ins = scalar("SELECT COALESCE(SUM(amount),0) FROM cash_moves WHERE kind='Entrée'")
        val fund = setting("opening_fund", "0").toDoubleOrNull() ?: 0.0
        val expected = fund + sales + ins - expenses
        val products = scalar("SELECT COUNT(*) FROM products").toInt()
        val stockValue = scalar("SELECT COALESCE(SUM(remaining_qty*price),0) FROM products")
        card("Ventes enregistrées", "${fmt(sales)} $currency")
        card("Fonds de départ", "${fmt(fund)} $currency")
        card("Dépenses et retraits", "${fmt(expenses)} $currency")
        card("Solde théorique de caisse", "${fmt(expected)} $currency")
        card("Produits enregistrés", products.toString())
        card("Valeur indicative du stock", "${fmt(stockValue)} $currency")
        label("Attention : le solde théorique est calculé à partir des opérations saisies. Compte l'argent réel séparément pour mesurer l'écart.")
        action("Configurer le fonds de départ et la devise") { showSettings() }
    }
    private fun card(title: String, value: String) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(14, 12, 14, 12); setBackgroundColor(Color.WHITE) }
        box.addView(TextView(this).apply { text = title; textSize = 14f; setTextColor(Color.DKGRAY) })
        box.addView(TextView(this).apply { text = value; textSize = 22f; setTextColor(RED); setTypeface(null, android.graphics.Typeface.BOLD) })
        body.addView(box, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 8 })
    }
    private fun showSettings() {
        reset("Paramètres de caisse")
        label("Fonds de départ (en $currency)")
        val fund = edit("Ex. 100", true); fund.setText(setting("opening_fund", "0"))
        label("Devise principale")
        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("USD", "CDF"))
        spinner.setSelection(if (currency == "CDF") 1 else 0); body.addView(spinner)
        action("Enregistrer les paramètres") {
            saveSetting("opening_fund", parse(fund).toString())
            currency = spinner.selectedItem.toString(); saveSetting("currency", currency)
            toast("Paramètres enregistrés"); showDashboard()
        }
    }
    private fun showProducts() {
        reset("Produits et stocks")
        val name = edit("Nom du produit")
        val start = edit("Quantité de départ", true)
        val added = edit("Quantité ajoutée", true)
        val price = edit("Prix unitaire ($currency)", true)
        action("Ajouter le produit") {
            val n = name.text.toString().trim(); val q0 = parse(start); val qa = parse(added); val p = parse(price)
            if (n.isBlank() || q0 < 0 || qa < 0 || p < 0) { toast("Vérifie le nom et les montants"); return@action }
            val cv = ContentValues().apply { put("name", n); put("start_qty", q0); put("added_qty", qa); put("remaining_qty", q0 + qa); put("price", p) }
            db.writableDatabase.insert("products", null, cv)
            toast("Produit ajouté"); showProducts()
        }
        label("Stock disponible = quantité de départ + quantités ajoutées")
        val c = db.readableDatabase.rawQuery("SELECT id,name,start_qty,added_qty,remaining_qty,price FROM products ORDER BY name", null)
        if (c.count == 0) label("Aucun produit enregistré.")
        while (c.moveToNext()) {
            val id = c.getLong(0); val n = c.getString(1); val q0 = c.getDouble(2); val qa = c.getDouble(3); val rem = c.getDouble(4); val p = c.getDouble(5)
            card(n, "Départ ${fmt(q0)} | Ajout ${fmt(qa)} | Restant ${fmt(rem)} | Prix ${fmt(p)} $currency")
            action("Ajouter du stock à : $n") { addStock(id, n, rem, qa) }
        }
        c.close()
    }
    private fun addStock(id: Long, name: String, remaining: Double, oldAdded: Double) {
        val e = EditText(this).apply { hint = "Quantité à ajouter"; inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL }
        AlertDialog.Builder(this).setTitle("Ajouter du stock : $name").setView(e).setPositiveButton("Enregistrer") { _, _ ->
            val q = e.text.toString().replace(',', '.').toDoubleOrNull() ?: 0.0
            if (q <= 0) { toast("Quantité invalide"); return@setPositiveButton }
            val cv = ContentValues().apply { put("added_qty", oldAdded + q); put("remaining_qty", remaining + q) }
            db.writableDatabase.update("products", cv, "id=?", arrayOf(id.toString())); showProducts()
        }.setNegativeButton("Annuler", null).show()
    }
    private fun showSale() {
        reset("Enregistrer une vente")
        val c = db.readableDatabase.rawQuery("SELECT id,name,remaining_qty,price FROM products WHERE remaining_qty>0 ORDER BY name", null)
        val ids = mutableListOf<Long>(); val names = mutableListOf<String>(); val stock = mutableListOf<Double>(); val prices = mutableListOf<Double>()
        while (c.moveToNext()) { ids.add(c.getLong(0)); names.add(c.getString(1)); stock.add(c.getDouble(2)); prices.add(c.getDouble(3)) }; c.close()
        if (names.isEmpty()) { label("Aucun produit en stock. Ajoute d'abord un produit."); return }
        val spinner = Spinner(this); spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names); body.addView(spinner)
        val qty = edit("Quantité vendue", true)
        val preview = TextView(this).apply { textSize = 17f; setTextColor(RED); setPadding(0, 8, 0, 8) }; body.addView(preview)
        fun updatePreview() { val i = spinner.selectedItemPosition.coerceIn(0, prices.lastIndex); preview.text = "Prix unitaire : ${fmt(prices[i])} $currency\nTotal estimé : ${fmt(parse(qty) * prices[i])} $currency\nStock disponible : ${fmt(stock[i])}" }
        spinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) = updatePreview()
        }
        qty.addTextChangedListener(object : android.text.TextWatcher { override fun beforeTextChanged(s: CharSequence?, st: Int, count: Int, after: Int) {}; override fun onTextChanged(s: CharSequence?, st: Int, before: Int, count: Int) { updatePreview() }; override fun afterTextChanged(s: android.text.Editable?) {} })
        updatePreview()
        action("Confirmer la vente") {
            val i = spinner.selectedItemPosition.coerceIn(0, names.lastIndex); val q = parse(qty)
            if (q <= 0 || q > stock[i]) { toast("Quantité invalide ou stock insuffisant"); return@action }
            val amount = q * prices[i]; val now = System.currentTimeMillis()
            db.writableDatabase.beginTransaction()
            try {
                db.writableDatabase.execSQL("UPDATE products SET remaining_qty=remaining_qty-? WHERE id=?", arrayOf(q, ids[i]))
                val cv = ContentValues().apply { put("product_id", ids[i]); put("product_name", names[i]); put("qty", q); put("amount", amount); put("currency", currency); put("created_at", now) }
                db.writableDatabase.insert("sales", null, cv); db.writableDatabase.setTransactionSuccessful()
            } finally { db.writableDatabase.endTransaction() }
            toast("Vente enregistrée : ${fmt(amount)} $currency"); showDashboard()
        }
    }
    private fun showCash() {
        reset("Mouvements de caisse")
        val spinner = Spinner(this); spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("Entrée", "Dépense", "Retrait")); body.addView(spinner)
        val amount = edit("Montant ($currency)", true); val note = edit("Motif / commentaire")
        action("Enregistrer le mouvement") {
            val a = parse(amount); val n = note.text.toString().trim(); val kind = spinner.selectedItem.toString()
            if (a <= 0) { toast("Le montant doit être supérieur à zéro"); return@action }
            val cv = ContentValues().apply { put("kind", kind); put("amount", a); put("note", n); put("currency", currency); put("created_at", System.currentTimeMillis()) }
            db.writableDatabase.insert("cash_moves", null, cv); toast("Mouvement enregistré"); showCash()
        }
        label("Derniers mouvements")
        val c = db.readableDatabase.rawQuery("SELECT kind,amount,note,created_at FROM cash_moves ORDER BY id DESC LIMIT 30", null)
        if (c.count == 0) label("Aucun mouvement enregistré.")
        while (c.moveToNext()) {
            val date = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(c.getLong(3)))
            card("${c.getString(0)} — ${fmt(c.getDouble(1))} $currency", "$date\n${c.getString(2) ?: ""}")
        }
        c.close()
        action("Compter l'argent réel et calculer l'écart") { countCash() }
    }
    private fun countCash() {
        val fund = setting("opening_fund", "0").toDoubleOrNull() ?: 0.0
        val sales = scalar("SELECT COALESCE(SUM(amount),0) FROM sales")
        val ins = scalar("SELECT COALESCE(SUM(amount),0) FROM cash_moves WHERE kind='Entrée'")
        val outs = scalar("SELECT COALESCE(SUM(amount),0) FROM cash_moves WHERE kind IN ('Dépense','Retrait')")
        val expected = fund + sales + ins - outs
        val e = EditText(this).apply { hint = "Argent réellement compté ($currency)"; inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL }
        AlertDialog.Builder(this).setTitle("Contrôle de caisse").setMessage("Solde théorique : ${fmt(expected)} $currency").setView(e).setPositiveButton("Calculer l'écart") { _, _ ->
            val actual = e.text.toString().replace(',', '.').toDoubleOrNull()
            if (actual == null) { toast("Montant invalide"); return@setPositiveButton }
            val diff = actual - expected
            val status = when { diff < -0.009 -> "Manquant"; diff > 0.009 -> "Surplus"; else -> "Caisse équilibrée" }
            AlertDialog.Builder(this).setTitle(status).setMessage("Théorique : ${fmt(expected)} $currency\nCompté : ${fmt(actual)} $currency\nÉcart : ${fmt(diff)} $currency").setPositiveButton("OK", null).show()
        }.setNegativeButton("Annuler", null).show()
    }
    override fun onDestroy() { db.close(); super.onDestroy() }
}
