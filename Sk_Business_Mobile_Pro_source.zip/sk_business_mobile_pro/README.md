# Sk Business Mobile Pro — prototype Android v0.1.0

Application Android native Kotlin, interface française, stockage local SQLite. Fonctionnalités incluses :
- Tableau de bord des ventes, fonds, sorties, solde théorique et valeur indicative du stock.
- Ajout de produits, quantités de départ et ajoutées, prix unitaire, stock restant.
- Enregistrement de ventes avec contrôle de stock et calcul automatique du total.
- Mouvements de caisse : entrée, dépense et retrait.
- Configuration d'un fonds de départ et choix d'une devise principale (USD ou CDF).
- Comptage de caisse et calcul d'écart (manquant/surplus).

## Limites connues de cette version
- Les données sont conservées sur un seul téléphone. Aucun serveur central ni compte propriétaire distant n'est encore connecté.
- Pas encore d'authentification, de rôles, de synchronisation multi-appareils, d'export PDF/Excel ni de rapports datés.
- Ne mélange pas USD et CDF dans une même caisse : la devise sélectionnée est un réglage d'affichage/saisie, pas un moteur de conversion.
- Le solde théorique est une première version simplifiée; les remboursements, transferts, ventes à crédit, clôtures de caisse et audit détaillé seront ajoutés ensuite.
- Ceci est un prototype de démarrage, pas une version prête pour une exploitation financière sensible.

## Obtenir l'APK depuis un téléphone Android
1. Connecte-toi ou crée un compte sur GitHub dans le navigateur du téléphone.
2. Crée un dépôt privé nommé `sk-business-mobile-pro`.
3. Téléverse tous les fichiers et dossiers de cette archive en conservant leur structure. L'interface web de GitHub permet d'ajouter des fichiers; pour un grand nombre de fichiers, un service de dépôt/import peut être plus pratique.
4. Ouvre l'onglet **Actions** du dépôt. Autorise les workflows si GitHub le demande.
5. Lance **Build Android APK** avec **Run workflow**, ou pousse un commit sur la branche `main`.
6. Quand le workflow réussit, ouvre l'exécution terminée, télécharge l'artefact `Sk-Business-Mobile-Pro-debug-APK`, puis décompresse-le pour obtenir `app-debug.apk`.
7. Sur Android, ouvre l'APK téléchargé et autorise l'installation depuis cette source si le système le demande. Installe uniquement l'APK provenant de ton dépôt.

## Compilation
- Android Gradle Plugin 8.7.3
- Gradle 8.9
- JDK 17 dans le workflow cloud
- `gradle assembleDebug`

L'APK de débogage n'est pas signé comme une publication Play Store. Une version de production signée et une sauvegarde sécurisée doivent être configurées avant diffusion.
